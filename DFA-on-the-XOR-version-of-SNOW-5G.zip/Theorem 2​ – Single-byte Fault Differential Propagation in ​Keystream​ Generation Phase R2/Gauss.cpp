#include <cstring>
#include "Gauss.h"
using namespace std;

void ShiftRows(u8 state[4][4]) {
    u8 temp = state[1][0];
    state[1][0] = state[1][1];
    state[1][1] = state[1][2];
    state[1][2] = state[1][3];
    state[1][3] = temp;

    std::swap(state[2][0], state[2][2]);
    std::swap(state[2][1], state[2][3]);

    temp = state[3][3];
    state[3][3] = state[3][2];
    state[3][2] = state[3][1];
    state[3][1] = state[3][0];
    state[3][0] = temp;
}

void MixColumns(u8 state[4][4]) {
    for (int col = 0; col < 4; ++col) {
        u8 a[4] = {state[0][col], state[1][col], state[2][col], state[3][col]};

        state[0][col] = gmul(0x02, a[0]) ^ gmul(0x03, a[1]) ^
                        gmul(0x01, a[2]) ^ gmul(0x01, a[3]);
        state[1][col] = gmul(0x01, a[0]) ^ gmul(0x02, a[1]) ^
                        gmul(0x03, a[2]) ^ gmul(0x01, a[3]);
        state[2][col] = gmul(0x01, a[0]) ^ gmul(0x01, a[1]) ^
                        gmul(0x02, a[2]) ^ gmul(0x03, a[3]);
        state[3][col] = gmul(0x03, a[0]) ^ gmul(0x01, a[1]) ^
                        gmul(0x01, a[2]) ^ gmul(0x02, a[3]);
    }
}

u8 InvSubByte(u8 byte) {
    return InvSBox[byte];
}

void InvSubBytes(u8 state[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            state[i][j] = InvSubByte(state[i][j]);
        }
    }
}

void InvShiftRows(u8 state[4][4]) {
    u8 temp = state[1][3];
    state[1][3] = state[1][2];
    state[1][2] = state[1][1];
    state[1][1] = state[1][0];
    state[1][0] = temp;

    std::swap(state[2][0], state[2][2]);
    std::swap(state[2][1], state[2][3]);

    temp = state[3][0];
    state[3][0] = state[3][1];
    state[3][1] = state[3][2];
    state[3][2] = state[3][3];
    state[3][3] = temp;
}

void InvMixColumns(u8 state[4][4]) {
    for (int col = 0; col < 4; ++col) {
        u8 a[4] = {state[0][col], state[1][col], state[2][col], state[3][col]};

        state[0][col] = gmul(0x0E, a[0]) ^ gmul(0x0B, a[1]) ^
                        gmul(0x0D, a[2]) ^ gmul(0x09, a[3]);
        state[1][col] = gmul(0x09, a[0]) ^ gmul(0x0E, a[1]) ^
                        gmul(0x0B, a[2]) ^ gmul(0x0D, a[3]);
        state[2][col] = gmul(0x0D, a[0]) ^ gmul(0x09, a[1]) ^
                        gmul(0x0E, a[2]) ^ gmul(0x0B, a[3]);
        state[3][col] = gmul(0x0B, a[0]) ^ gmul(0x0D, a[1]) ^
                        gmul(0x09, a[2]) ^ gmul(0x0E, a[3]);
    }
}

u8 gmul(u8 a, u8 b) {
    u8 p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        bool high_bit = a & 0x80;
        a = (a << 1);
        if (high_bit) a ^= 0x1B;
        b >>= 1;
    }
    return p;
}

// ShiftRows the coefficient matrix
void apply_shiftrows(CoeffMatrix& coeff) {
    CoeffMatrix temp;
    memcpy(&temp, &coeff, sizeof(CoeffMatrix));

    for(int r=0; r<4; ++r) {
        for(int c=0; c<4; ++c) {
            int new_c = (c - r + 4) % 4;
            memcpy(coeff[r][new_c], temp[r][c], VAR_COUNT);
        }
    }
}

// MixColumns the coefficient matrix
void apply_mixcolumns(CoeffMatrix& coeff) {
    const u8 mix[4][4] = {
            {0x02, 0x03, 0x01, 0x01},
            {0x01, 0x02, 0x03, 0x01},
            {0x01, 0x01, 0x02, 0x03},
            {0x03, 0x01, 0x01, 0x02}
    };

    CoeffMatrix temp;
    memset(&temp, 0, sizeof(temp));

    for(int c=0; c<4; ++c) {
        for(int r=0; r<4; ++r) {
            for(int v=0; v<VAR_COUNT; ++v) {
                for(int mc=0; mc<4; ++mc) {
                    temp[r][c][v] ^= gmul(mix[r][mc], coeff[mc][c][v]);
                }
            }
        }
    }
    memcpy(&coeff, &temp, sizeof(CoeffMatrix));
}

// transpose the coefficient matrix
void transpose_coeff(CoeffMatrix& coeff) {
    CoeffMatrix temp;
    for(int i=0; i<4; ++i) {
        for(int j=0; j<4; ++j) {
            memcpy(temp[i][j], coeff[j][i], VAR_COUNT);
        }
    }
    memcpy(&coeff, &temp, sizeof(CoeffMatrix));
}

// coefficients of C
void get_C_coeff(int i, int j, CoeffMatrix& coeff) {
    memset(&coeff, 0, sizeof(CoeffMatrix));
    const int target_col = (i - j + 4) % 4;

    // the position of S1-S4 in the target column
    for(int k=0; k<4; ++k) {
        int row = (j + k + 4) % 4;
        coeff[row][target_col][S1 + k] = 1;
    }

    apply_shiftrows(coeff);
    apply_mixcolumns(coeff);
    transpose_coeff(coeff);
}

// coefficients of D
void get_D_coeff(int i, int j, CoeffMatrix& coeff) {
    memset(&coeff, 0, sizeof(CoeffMatrix));
    const int target_row = (i-j+4)%4;

    // the position of M1-M4 in the target row
    for(int k=0; k<4; ++k) {
        int col = (j + k + 4) % 4;
        coeff[target_row][col][M1 + k] = 1;
    }

    apply_shiftrows(coeff);
    apply_mixcolumns(coeff);
}

CoreSolution gaussian_elimination_core(const vector<vector<u8>>& A_origin,
                                       const vector<u8>& b_origin) {
    const int n = A_origin.size();
    const int m = VAR_COUNT;
    CoreSolution sol;
    vector<vector<u8>> A = A_origin;
    vector<u8> b = b_origin;

    vector<int> pivot_map(m, -1);
    int row = 0;

    for(int col=0; col<m; ++col) {
        int pivot = -1;
        for(int i=row; i<n; ++i) {
            if(A[i][col] != 0) {
                pivot = i;
                break;
            }
        }
        if(pivot == -1) continue;

        swap(A[row], A[pivot]);
        swap(b[row], b[pivot]);

        u8 inv = 1;
        while(gmul(A[row][col], inv) != 1) ++inv;
        for(int j=col; j<m; ++j)
            A[row][j] = gmul(A[row][j], inv);
        b[row] = gmul(b[row], inv);

        for(int i=0; i<n; ++i) {
            if(i != row && A[i][col] != 0) {
                u8 factor = A[i][col];
                for(int j=col; j<m; ++j)
                    A[i][j] ^= gmul(factor, A[row][j]);
                b[i] ^= gmul(factor, b[row]);
            }
        }

        pivot_map[col] = row++;
    }

    sol.has_unique = true;
    for(int col=0; col<m; ++col) {
        if(pivot_map[col] == -1) {
            sol.has_unique = false;
            break;
        }
    }

    for(int col=0; col<m; ++col) {
        if(pivot_map[col] != -1) {
            sol.vars[col] = b[pivot_map[col]];
        } else {
            sol.vars[col] = 0;
        }
    }

    return sol;
}

bool solveCore2(const u8 C[4][4], CoreSolution& sol, int i, int j) {
    vector<vector<u8>> equations;
    vector<u8> constants;

    vector<u8> eq(VAR_COUNT, 0);
    CoeffMatrix C_coeff, D_coeff;

    get_C_coeff(i, j, C_coeff);
    get_D_coeff(i, j, D_coeff);

    for (int s = 0; s < 4; ++s) {
        for (int t = 0; t < 4; ++t) {
            eq.assign(VAR_COUNT, 0);
            for (int v = 0; v < VAR_COUNT; ++v) {
                eq[v] = C_coeff[s][t][v] ^ D_coeff[s][t][v];
            }
            equations.push_back(eq);
            constants.push_back(C[s][t]);
        }
    }

    sol = gaussian_elimination_core(equations, constants);
    return sol.has_unique;
}

void print_matrix(const char* name, const u8 m[4][4]) {
    cout << name << ":\n";
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << hex << setw(2) << setfill('0')
                 << static_cast<int>(m[i][j]) << " ";
        }
        cout << endl;
    }
    cout << endl;
}