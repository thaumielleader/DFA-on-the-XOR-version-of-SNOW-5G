// Experiment for Theorem 2: By injecting a single fault into R2 during the keystream generation phase,
// we obtained 2 or 4 candidate values for each of 14 state bytes, which is consistent with the theoretical predictions of Theorem 2.
#include "Gauss.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <random>
#include <iostream>
#include <algorithm>
#include <chrono>

typedef uint16_t u16;
typedef uint32_t u32;
u8 Sigma[16] = {0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15};
u32 AesKey1[4] = {0, 0, 0, 0};
u32 AesKey2[4] = {0, 0, 0, 0};
#define MAKEU32(a, b) (((u32)(a) << 16) | ((u32)(b) ))
#define MAKEU16(a, b) (((u16)(a) << 8) | ((u16)(b) ))

// Define some global variables to store the normal and faulty states at all times.
u8 d_zs[8][16];
u8 d_R1s[7][4][4], d_R2s[7][4][4], d_R3s[7][4][4];
u8 R1s[7][4][4],R2s[7][4][4];

int timing = 0;

// solution sets
std::vector<std::vector<std::vector<std::vector<int>>>> solutions;  //R1
std::vector<std::vector<std::vector<std::vector<int>>>> solutions2; //R2

// initialize solution sets
void initializeSolutions() {
    solutions.resize(6);
    for (int t = 0; t < 6; ++t) {
        solutions[t].resize(16);
        for (int i = 0; i < 16; ++i) {
            solutions[t][i].resize(16);
            for (int j = 0; j < 16; ++j) {
                solutions[t][i][j].clear();
                solutions[t][i][j].reserve(8); // Space reserved for performance optimization, 2 or 4 candidates
            }
        }
    }
}
void initializeSolutions2() {
    solutions2.resize(6);
    for (int t = 0; t < 6; ++t) {
        solutions2[t].resize(16);
        for (int i = 0; i < 16; ++i) {
            solutions2[t][i].resize(16);
            for (int j = 0; j < 16; ++j) {
                solutions2[t][i][j].clear();
                solutions2[t][i][j].reserve(8);
            }
        }
    }
}

struct Snow5GXOR {
    u16 A[16], B[16];
    u32 R1[4], R2[4], R3[4];
    u16 f_A[16], f_B[16];
    u32 f_R1[4], f_R2[4], f_R3[4];
    void aes_enc_round(u32 *result, u32 *state, u32 *roundKey) {
#define ROTL32(word32, offset) ((word32 << offset) | (word32 >> (32 - offset)))
#define SB(index, offset) (((u32)(sb[(index) % 16])) << (offset * 8))
#define MKSTEP(j)\
w = SB(j * 4 + 0, 3) | SB(j * 4 + 5, 0) | SB(j * 4 + 10, 1) | SB(j * 4 + 15, 2);\
t = ROTL32(w, 16) ^ ((w << 1) & 0xfefefefeUL) ^ (((w >> 7) & 0x01010101UL) * 0x1b);\
result[j] = roundKey[j] ^ w ^ t ^ ROTL32(t, 8)
        u32 w, t;
        u8 sb[16];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                sb[i * 4 + j] = SBox[(state[i] >> (j * 8)) & 0xff];
        MKSTEP(0);
        MKSTEP(1);
        MKSTEP(2);
        MKSTEP(3);
    }

    u16 mul_x(u16 v, u16 c) {
        if (v & 0x8000)
            return (v << 1) ^ c;
        else
            return (v << 1);
    }

    void permute_sigma(u32 *state) {
        u8 tmp[16];
        for (int i = 0; i < 16; i++)
            tmp[i] = (u8) (state[Sigma[i] >> 2] >> ((Sigma[i] & 3) << 3));
        for (int i = 0; i < 4; i++)
            state[i] = MAKEU32(MAKEU16(tmp[4 * i + 3], tmp[4 * i + 2]),
                               MAKEU16(tmp[4 * i + 1], tmp[4 * i]));
    }

    void fsm_update(void) {
        // update FSM
        u32 R1temp[4];
        memcpy(R1temp, R1, sizeof(R1));
        for (int i = 0; i < 4; i++) {
            u32 T2 = MAKEU32(A[2 * i + 9], A[2 * i + 8]);
            R1[i] = (T2 ^ R3[i]) ^ R2[i];
        }
        permute_sigma(R1);
        aes_enc_round(R3, R2, AesKey2);
        aes_enc_round(R2, R1temp, AesKey1);

        // update faulty FSM
        u32 f_R1temp[4];
        memcpy(f_R1temp, f_R1, sizeof(f_R1));
        for (int i = 0; i < 4; i++) {
            u32 f_T2 = MAKEU32(f_A[2 * i + 9], f_A[2 * i + 8]);
            f_R1[i] = (f_T2 ^ f_R3[i]) ^ f_R2[i];
        }
        permute_sigma(f_R1);
        aes_enc_round(f_R3, f_R2, AesKey2);
        aes_enc_round(f_R2, f_R1temp, AesKey1);
    }

    void lfsr_update(void) {
        // update LFSR
        for (int i = 0; i < 8; i++) {
            u16 u = B[0] ^ mul_x(A[0], 0x990f) ^ A[7];
            u16 v = A[0] ^ mul_x(B[0], 0xc963) ^ B[8];
            for (int j = 0; j < 15; j++) {
                A[j] = A[j + 1];
                B[j] = B[j + 1];
            }
            A[15] = u;
            B[15] = v;
        }

        // update faulty LFSR
        for (int i = 0; i < 8; i++) {
            u16 f_u = f_B[0] ^ mul_x(f_A[0], 0x990f) ^ f_A[7];
            u16 f_v = f_A[0] ^ mul_x(f_B[0], 0xc963) ^ f_B[8];
            for (int j = 0; j < 15; j++) {
                f_A[j] = f_A[j + 1];
                f_B[j] = f_B[j + 1];
            }
            f_A[15] = f_u;
            f_B[15] = f_v;
        }
    }

    void keystream(u8 *z,u8 *f_z, int t, int row, int col, int error, int flag) {
        // store the normal and faulty states at all times to check if our solution is correct
        for(int j=0;j<4;j++)
            for(int i=0;i<4;i++){
                R1s[timing][i][j] = (R1[j] >> (8*((i+4)%4))) &0xff;
                R2s[timing][i][j] = (R2[j] >> (8*((i+4)%4))) &0xff;
            }

        // inject faults into R1 or R2
        if(t==timing){
            if(flag==1) f_R1[col] ^= (error<<(8*((row+4)%4))) ;
            if(flag==2) f_R2[col] ^= (error<<(8*((row+4)%4))) ;
        }

        // keystream generation
        for (int i = 0; i < 4; i++) {
            u32 T1 = MAKEU32(B[2 * i + 9], B[2 * i + 8]);
            u32 v = (T1 ^ R1[i]) ^ R2[i];
            z[i * 4 + 0] = (v >> 0) & 0xff;
            z[i * 4 + 1] = (v >> 8) & 0xff;
            z[i * 4 + 2] = (v >> 16) & 0xff;
            z[i * 4 + 3] = (v >> 24) & 0xff;
        }

        // faulty keystream generation
        for (int i = 0; i < 4; i++) {
            u32 f_T1 = MAKEU32(f_B[2 * i + 9], f_B[2 * i + 8]);
            u32 f_v = (f_T1 ^ f_R1[i]) ^ f_R2[i];
            f_z[i * 4 + 0] = (f_v >> 0) & 0xff;
            f_z[i * 4 + 1] = (f_v >> 8) & 0xff;
            f_z[i * 4 + 2] = (f_v >> 16) & 0xff;
            f_z[i * 4 + 3] = (f_v >> 24) & 0xff;
        }

        fsm_update();
        lfsr_update();
        timing++;
    }

    void keyiv_setup(u8 *key, u8 *iv) {
        for (int i = 0; i < 8; i++) {
            A[i] = MAKEU16(iv[2 * i + 1], iv[2 * i]);
            A[i + 8] = MAKEU16(key[2 * i + 1], key[2 * i]);
            B[i] = 0x0000;
            B[i + 8] = MAKEU16(key[2 * i + 17], key[2 * i + 16]);
        }
        for (int i = 0; i < 4; i++)
            R1[i] = R2[i] = R3[i] = 0x00000000;

        // initialize faulty states
        for (int i = 0; i < 8; i++) {
            f_A[i] = MAKEU16(iv[2 * i + 1], iv[2 * i]);
            f_A[i + 8] = MAKEU16(key[2 * i + 1], key[2 * i]);
            f_B[i] = 0x0000;
            f_B[i + 8] = MAKEU16(key[2 * i + 17], key[2 * i + 16]);
        }
        for (int i = 0; i < 4; i++)
            f_R1[i] = f_R2[i] = f_R3[i] = 0x00000000;

        // initiation phase
        for (int i = 0; i < 16; i++) {
            u8 z[16],f_z[16];
            keystream(z,f_z,0,0,0,0,0);
            for (int j = 0; j < 8; j++){
                A[j + 8] ^= MAKEU16(z[2 * j + 1], z[2 * j]);
                f_A[j + 8] ^= MAKEU16(f_z[2 * j + 1], f_z[2 * j]);
            }
            if (i == 14)
                for (int j = 0; j < 4; j++){
                    R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 3], key[4 * j + 2]),
                                     MAKEU16(key[4 * j + 1], key[4 * j + 0]));
                    f_R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 3], key[4 * j + 2]),
                                       MAKEU16(key[4 * j + 1], key[4 * j + 0]));
                }
            if (i == 15)
                for (int j = 0; j < 4; j++){
                    R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 19], key[4 * j + 18]),
                                     MAKEU16(key[4 * j + 17], key[4 * j + 16]));
                    f_R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 19], key[4 * j + 18]),
                                       MAKEU16(key[4 * j + 17], key[4 * j + 16]));
                }
        }
    }
};

// recover state byte of R1 and R2 using input and output differences
void RB(int t, int i, int j, int flag){
    std::vector<int> newSolutions;
    newSolutions.reserve(8);
    int e,E;    // input and output differences

    if(flag==1){
        e = d_R1s[t][i][j]; // input difference is at (i,j)
        E = d_R2s[t+1][(i+1+4)%4][(j-i+4)%4];   // output difference is at (i+1,j-i). The column j-i is (2*E,E,E,3*E)>>>i bytes.
        for(int x=0;x<256;x++){
            if( !solutions[t][i][j].empty() &&
                std::find(solutions[t][i][j].begin(), solutions[t][i][j].end(), x) == solutions[t][i][j].end()) continue;

            int d = SBox[x] ^ SBox[ x ^ e ];
            if ( d == E ){
                newSolutions.push_back(x);
            }
        }
        solutions[t][i][j] = std::move(newSolutions);
    }
    if(flag==2){
        e = d_R2s[t][i][j];
        E = d_R3s[t+1][(i+1+4)%4][(j-i+4)%4];
        for(int x=0;x<256;x++){
            if( !solutions2[t][i][j].empty() &&
                std::find(solutions2[t][i][j].begin(), solutions2[t][i][j].end(), x) == solutions2[t][i][j].end()) continue;

            int d = SBox[x] ^ SBox[ x ^ e ];
            if ( d == E ){
                newSolutions.push_back(x);
            }
        }
        solutions2[t][i][j] = std::move(newSolutions);
    }
}

int main() {
    auto start = std::chrono::high_resolution_clock::now();
    freopen("Recover Inner States.txt", "w", stdout);

    Snow5GXOR snow;
    u8 key[32];
    u8 iv[16];
    for (int i = 0; i < 32; i++) {
        key[i] = 0;
    }
    for (int i = 0; i < 16; i++) {
        iv[i] = 0;
    }

    // initialize solution sets
    initializeSolutions();
    initializeSolutions2();

    int clock2 = 0;
    int row=0;
    for(int col=0;col<1;col++){
        u8 z[16],f_z[16];
        for(int t=0;t<7;t++){   // initialize difference sets
            for(int i=0;i<4;i++){
                for(int j=0;j<4;j++){
                    d_R1s[t][i][j] = 0;
                    d_R2s[t][i][j] = 0;
                    d_R3s[t][i][j] = 0;
                    d_zs[t][4*j+i] = 0;
                }
            }
        }

        snow.keyiv_setup(key, iv);
        timing = 0;

        int error2 = (rand()%255)+1;
        printf("The error2 is %d, and it is at (%d,%d) of R2 in time %d\n",error2,row,col,clock2);
        for (int t = 0; t < 7; t++) {
            snow.keystream(z,f_z,clock2,row,col,error2,2);
            for (int i = 0; i < 16; i++) {
                d_zs[t][i] = z[i] ^ f_z[i]; // compute differences of keystreams. This is the only information which attackers know.
            }
        }

        // put the differences of keystreams into d_R1s, d_R2s, d_R3s
        for(int j=0;j<4;j++)
            for(int i=0;i<4;i++){
                d_R2s[clock2+0][i][j] = d_zs[clock2+0][4*j+i];
                d_R1s[clock2+1][i][j] = d_zs[clock2+1][4*j+i];
            }

        // compute differences of R1 and R2 at time t+2
        u8 m,n;
        if( ((row+1+4)%4) != ((row-col+4)%4) ) m=d_zs[clock2+2][ 4*((row+1+4)%4)+((col-row+4)%4) ];
        if( ((row+2+4)%4) != ((row-col+4)%4) ) m=d_zs[clock2+2][ 4*((row+2+4)%4)+((col-row+4)%4) ];
        d_R1s[clock2+2][(col-row+4)%4][row] = gmul(2,m);
        d_R1s[clock2+2][(col-row+4)%4][(row+1+4)%4] = m;
        d_R1s[clock2+2][(col-row+4)%4][(row+2+4)%4] = m;
        d_R1s[clock2+2][(col-row+4)%4][(row+3+4)%4] = gmul(3,m);

        if( ((col+1+4)%4) != ((col-row+4)%4) ) n=d_zs[clock2+2][4*((row-col+4)%4)+((col+1+4)%4)];
        if( ((col+2+4)%4) != ((col-row+4)%4) ) n=d_zs[clock2+2][4*((row-col+4)%4)+((col+2+4)%4)];
        d_R2s[clock2+2][col][(row-col+4)%4] = gmul(2,n);
        d_R2s[clock2+2][(col+1+4)%4][(row-col+4)%4] = n;
        d_R2s[clock2+2][(col+2+4)%4][(row-col+4)%4] = n;
        d_R2s[clock2+2][(col+3+4)%4][(row-col+4)%4] = gmul(3,n);

        // compute differences of R3 at time t+1
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                d_R3s[clock2+1][i][j] = d_R1s[clock2+2][j][i];
            }
        }

        // compute difference at time t+3
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                d_R1s[clock2+3][i][j] = d_R2s[clock2+2][j][i];
            }
        }
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                d_R2s[clock2+3][i][j] = d_zs[clock2+3][4*j+i] ^ d_R1s[3][i][j];
            }
        }

        // Get the difference of R1 at time t+3
        u8 C[4][4]={0};
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                C[i][j] = d_zs[clock2+4][4*j+i] ^ d_R2s[clock2+3][j][i];
            }
        }
        CoreSolution sol2;
        solveCore2(C,sol2,row,col);

        // compute differences of R3 at time t+3 and R2 at time t+4
        d_R3s[clock2+3][col][(row-col+4)%4] = sol2.vars[S1];
        d_R3s[clock2+3][(col+1+4)%4][(row-col+4)%4] = sol2.vars[S2];
        d_R3s[clock2+3][(col+2+4)%4][(row-col+4)%4] = sol2.vars[S3];
        d_R3s[clock2+3][(col+3+4)%4][(row-col+4)%4] = sol2.vars[S4];
        ShiftRows(d_R3s[clock2+3]);
        MixColumns(d_R3s[clock2+3]);

        d_R2s[clock2+4][(row-col+4)%4][col] = sol2.vars[M1];
        d_R2s[clock2+4][(row-col+4)%4][(col+1+4)%4] = sol2.vars[M2];
        d_R2s[clock2+4][(row-col+4)%4][(col+2+4)%4] = sol2.vars[M3];
        d_R2s[clock2+4][(row-col+4)%4][(col+3+4)%4] = sol2.vars[M4];
        ShiftRows(d_R2s[clock2+4]);
        MixColumns(d_R2s[clock2+4]);

        //---------------------------------In the above, we solved the input difference and output difference.
        // In the following, we solve the candidate values of the state bytes.--------------------------------

        // solve R2[i][j] at time 0
        RB(clock2+0,row,col,2);
        printf("The solutions of R2[%d][%d](%d) at time %d are: ",row,col,R2s[clock2+0][row][col],clock2+0);
        for(auto x: solutions2[clock2+0][row][col]){
            printf("%d ",x);
        }
        printf("\n");

        // solve R1[j][i] at time 1
        RB(clock2+1,col,row,1);
        printf("The solutions of R1[%d][%d](%d) at time %d are: ",col,row,R1s[clock2+1][col][row],clock2+1);
        for(auto x: solutions[clock2+1][col][row]){
            printf("%d ",x);
        }
        printf("\n");

        // solve column i-j of R2 at time 2
        for(int i=0;i<4;i++){
            RB(clock2+2,i,(row-col+4)%4,2);
            printf("The solutions of R2[%d][%d](%d) at time %d are: ",i,(row-col+4)%4,R2s[clock2+2][i][(row-col+4)%4],clock2+2);
            for(auto x: solutions2[clock2+2][i][(row-col+4)%4]){       // 这是solutions2！！！别搞错了！！！
                printf("%d ",x);
            }
            printf("\n");
        }

        // solve row j-i of R1 at time 2
        for(int j=0;j<4;j++){
            RB(clock2+2,(col-row+4)%4,j,1);
            printf("The solutions of R1[%d][%d](%d) at time %d are: ",(col-row+4)%4,j,R1s[clock2+2][(col-row+4)%4][j],clock2+2);
            for(auto x: solutions[clock2+2][(col-row+4)%4][j]){
                printf("%d ",x);
            }
            printf("\n");
        }

        // solve row 0 of R1 at time 3
        for(int j=0;j<4;j++){
            RB(clock2+3,(row-col+4)%4,j,1);
            printf("The solutions of R1[%d][%d](%d) at time %d are: ",(row-col+4)%4,j,R1s[clock2+3][(row-col+4)%4][j],clock2+3);
            for(auto x: solutions[clock2+3][(row-col+4)%4][j]){
                printf("%d ",x);
            }
            printf("\n");
        }
        printf("\n");
    }


    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    printf("Elapsed time: %.6fs\n", elapsed.count());

    return 0;
}

// It is recommended to enter the following code in the terminal to run the program:
//g++ -std=c++11 main.cpp Gauss.cpp -o main
//.\main.exe