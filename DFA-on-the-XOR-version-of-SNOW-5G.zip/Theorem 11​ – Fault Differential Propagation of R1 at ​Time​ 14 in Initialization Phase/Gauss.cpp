#include "Gauss.h"
#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

u8 InvSubByte(u8 byte) {
    return InvSBox[byte];
}

void InvSubBytes(u8 state[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            state[i][j] = InvSubByte(state[i][j]);
        }
    }
}

void InvShiftRows(u8 state[4][4]) {
    u8 temp = state[1][3];
    state[1][3] = state[1][2];
    state[1][2] = state[1][1];
    state[1][1] = state[1][0];
    state[1][0] = temp;

    std::swap(state[2][0], state[2][2]);
    std::swap(state[2][1], state[2][3]);

    temp = state[3][0];
    state[3][0] = state[3][1];
    state[3][1] = state[3][2];
    state[3][2] = state[3][3];
    state[3][3] = temp;
}

void InvMixColumns(u8 state[4][4]) {
    for (int col = 0; col < 4; ++col) {
        u8 a[4] = {state[0][col], state[1][col], state[2][col], state[3][col]};

        state[0][col] = gmul(0x0E, a[0]) ^ gmul(0x0B, a[1]) ^
                        gmul(0x0D, a[2]) ^ gmul(0x09, a[3]);
        state[1][col] = gmul(0x09, a[0]) ^ gmul(0x0E, a[1]) ^
                        gmul(0x0B, a[2]) ^ gmul(0x0D, a[3]);
        state[2][col] = gmul(0x0D, a[0]) ^ gmul(0x09, a[1]) ^
                        gmul(0x0E, a[2]) ^ gmul(0x0B, a[3]);
        state[3][col] = gmul(0x0B, a[0]) ^ gmul(0x0D, a[1]) ^
                        gmul(0x09, a[2]) ^ gmul(0x0E, a[3]);
    }
}

u8 gmul(u8 a, u8 b) {
    u8 p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        bool high_bit = a & 0x80;
        a = (a << 1);
        if (high_bit) a ^= 0x1B;
        b >>= 1;
    }
    return p;
}

CoreSolution gaussian_elimination_core(const vector<vector<u8>>& A_origin,
                                       const vector<u8>& b_origin) {
    const int n = A_origin.size();
    const int m = A_origin[0].size();
    CoreSolution sol;
    vector<vector<u8>> A = A_origin;
    vector<u8> b = b_origin;

    vector<int> pivot_map(m, -1);
    int row = 0;

    for (int col = 0; col < m; ++col) {
        int pivot = -1;
        for (int i = row; i < n; ++i) {
            if (A[i][col] != 0) {
                pivot = i;
                break;
            }
        }
        if (pivot == -1) {
            sol.has_unique = false;
            return sol;
        }

        swap(A[row], A[pivot]);
        swap(b[row], b[pivot]);
        u8 inv = 1;
        for (u8 k = 1; k < 256; ++k) {
            if (gmul(A[row][col], k) == 1) {
                inv = k;
                break;
            }
        }
        for (int j = 0; j < m; ++j)
            A[row][j] = gmul(A[row][j], inv);
        b[row] = gmul(b[row], inv);

        for (int i = 0; i < n; ++i) {
            if (i != row && A[i][col] != 0) {
                u8 factor = A[i][col];
                for (int j = 0; j < m; ++j)
                    A[i][j] ^= gmul(factor, A[row][j]);
                b[i] ^= gmul(factor, b[row]);
            }
        }

        pivot_map[col] = row++;
    }

    sol.has_unique = true;
    for (int col = 0; col < m; ++col) {
        if (pivot_map[col] == -1) {
            sol.has_unique = false;
            break;
        }
    }

    if (sol.has_unique) {
        sol.S2 = b[pivot_map[0]];
        sol.S3 = b[pivot_map[1]];
        sol.S4 = b[pivot_map[2]];
        sol.M1 = b[pivot_map[3]];
        sol.M2 = b[pivot_map[4]];
        sol.M3 = b[pivot_map[5]];
        sol.M4 = b[pivot_map[6]];
    }
    return sol;
}

bool solveCore(const u8 C[4][4], u8 B[4][4], CoreSolution& sol) {
    vector<vector<u8>> coeff;
    vector<u8> constants;

    // using the 1~3 row to solve the 7 variables
    for (int i = 1; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            vector<u8> row(7, 0); // 变量：S2(0), S3(1), S4(2), M1(3), M2(4), M3(5), M4(6)

            // generate the coefficient matrix of A
            switch(i) {
                case 1: // 原第二行对应S2
                    row[0] = (j == 3) ? 0x02 : (j == 2) ? 0x03 : 0x01;
                    break;
                case 2: // 原第三行对应S3
                    row[1] = (j == 1) ? 0x03 : (j == 2) ? 0x02 : 0x01;
                    break;
                case 3: // 原第四行对应S4
                    row[2] = (j == 0) ? 0x03 : (j == 1) ? 0x02 : 0x01;
                    break;
            }

            // generate the coefficient matrix of B
            u8 b_coeff = (i == 3) ? 0x03 : 0x01;
            row[3 + j] = b_coeff;

            coeff.push_back(row);
            constants.push_back(C[i][j]);
        }
    }

    sol = gaussian_elimination_core(coeff, constants);
    if (!sol.has_unique) return false;

    const u8 B_coeffs[4] = {0x02, 0x01, 0x01, 0x03};
    for (int col = 0; col < 4; ++col) {
        u8 M = (col == 0) ? sol.M1 : (col == 1) ? sol.M2 : (col == 2) ? sol.M3 : sol.M4;
        for (int row = 0; row < 4; ++row) {
            B[row][col] = gmul(B_coeffs[row], M);
        }
    }
    return true;
}

void print_matrix(const char* name, const u8 m[4][4]) {
    cout << name << ":\n";
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << hex << setw(2) << setfill('0')
                 << static_cast<int>(m[i][j]) << " ";
        }
        cout << endl;
    }
    cout << endl;
}