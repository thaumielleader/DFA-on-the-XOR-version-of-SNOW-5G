// Experiment for Theorem 11: By injecting a single fault into R1 at time 14 during the initiation phase,
// we obtained 2 or 4 candidate values for each of 5 state bytes, which is consistent with the theoretical predictions of Theorem 11.
#include "Gauss.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <random>
#include <iostream>
#include <algorithm>
#include <chrono>

typedef uint16_t u16;
typedef uint32_t u32;
u8 Sigma[16] = {0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15};
u32 AesKey1[4] = {0, 0, 0, 0};
u32 AesKey2[4] = {0, 0, 0, 0};
#define MAKEU32(a, b) (((u32)(a) << 16) | ((u32)(b) ))
#define MAKEU16(a, b) (((u16)(a) << 8) | ((u16)(b) ))

// Define some global variables to store the normal and faulty states at all times.
u8 d_zs[8][16]; // keystream difference
u8 d_R1s[5][4][4], d_R2s[5][4][4], d_R3s[5][4][4]; // FSM difference
u8 R1s[5][4][4],R2s[5][4][4],R3s[5][4][4],f_R1s[5][4][4],f_R2s[5][4][4],f_R3s[5][4][4]; // faulty states

int timing = 0;

// solution sets
std::vector<std::vector<std::vector<std::vector<int>>>> solutions;  //R1
std::vector<std::vector<std::vector<std::vector<int>>>> solutions2;  //R2

// initialize solution sets
void initializeSolutions() {
    solutions.resize(6);
    for (int t = 0; t < 6; ++t) {
        solutions[t].resize(16);
        for (int i = 0; i < 16; ++i) {
            solutions[t][i].resize(16);
            for (int j = 0; j < 16; ++j) {
                solutions[t][i][j].clear();
                solutions[t][i][j].reserve(8);
            }
        }
    }
}
void initializeSolutions2() {
    solutions2.resize(6);
    for (int t = 0; t < 6; ++t) {
        solutions2[t].resize(16);
        for (int i = 0; i < 16; ++i) {
            solutions2[t][i].resize(16);
            for (int j = 0; j < 16; ++j) {
                solutions2[t][i][j].clear();
                solutions2[t][i][j].reserve(8);
            }
        }
    }
}

struct Snow5GXOR {
    u16 A[16], B[16]; // LFSR
    u32 R1[4], R2[4], R3[4]; // FSM
    u16 f_A[16], f_B[16]; // faulty LFSR
    u32 f_R1[4], f_R2[4], f_R3[4]; // fauly FSM
    void aes_enc_round(u32 *result, u32 *state, u32 *roundKey) {
#define ROTL32(word32, offset) ((word32 << offset) | (word32 >> (32 - offset)))
#define SB(index, offset) (((u32)(sb[(index) % 16])) << (offset * 8))
#define MKSTEP(j)\
w = SB(j * 4 + 0, 3) | SB(j * 4 + 5, 0) | SB(j * 4 + 10, 1) | SB(j * 4 + 15, 2);\
t = ROTL32(w, 16) ^ ((w << 1) & 0xfefefefeUL) ^ (((w >> 7) & 0x01010101UL) * 0x1b);\
result[j] = roundKey[j] ^ w ^ t ^ ROTL32(t, 8)
        u32 w, t;
        u8 sb[16];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                sb[i * 4 + j] = SBox[(state[i] >> (j * 8)) & 0xff];
        MKSTEP(0);
        MKSTEP(1);
        MKSTEP(2);
        MKSTEP(3);
    }

    u16 mul_x(u16 v, u16 c) {
        if (v & 0x8000)
            return (v << 1) ^ c;
        else
            return (v << 1);
    }

    void permute_sigma(u32 *state) {
        u8 tmp[16];
        for (int i = 0; i < 16; i++)
            tmp[i] = (u8) (state[Sigma[i] >> 2] >> ((Sigma[i] & 3) << 3));
        for (int i = 0; i < 4; i++)
            state[i] = MAKEU32(MAKEU16(tmp[4 * i + 3], tmp[4 * i + 2]),
                               MAKEU16(tmp[4 * i + 1], tmp[4 * i]));
    }

    //  传送状态
    void transFSM(u32 jie[], u32 chuan[]){
        for (int i = 0; i < 4; i++) {
            jie[i] = chuan[i];
        }
    }
    void transLFSR(u16 jie[], u16 chuan[]){
        for (int i = 0; i < 16; i++) {
            jie[i] = chuan[i];
        }
    }

    void fsm_update(void) {
        u32 R1temp[4];
        memcpy(R1temp, R1, sizeof(R1));
        for (int i = 0; i < 4; i++) {
            u32 T2 = MAKEU32(A[2 * i + 9], A[2 * i + 8]);
            R1[i] = (T2 ^ R3[i]) ^ R2[i];
        }
        permute_sigma(R1);
        aes_enc_round(R3, R2, AesKey2);
        aes_enc_round(R2, R1temp, AesKey1);

        u32 f_R1temp[4];
        memcpy(f_R1temp, f_R1, sizeof(f_R1));
        for (int i = 0; i < 4; i++) {
            u32 f_T2 = MAKEU32(f_A[2 * i + 9], f_A[2 * i + 8]);
            f_R1[i] = (f_T2 ^ f_R3[i]) ^ f_R2[i];
        }
        permute_sigma(f_R1);
        aes_enc_round(f_R3, f_R2, AesKey2);
        aes_enc_round(f_R2, f_R1temp, AesKey1);
    }

    void lfsr_update(void) {
        for (int i = 0; i < 8; i++) {
            u16 u = B[0] ^ mul_x(A[0], 0x990f) ^ A[7];
            u16 v = A[0] ^ mul_x(B[0], 0xc963) ^ B[8];
            for (int j = 0; j < 15; j++) {
                A[j] = A[j + 1];
                B[j] = B[j + 1];
            }
            A[15] = u;
            B[15] = v;
        }

        for (int i = 0; i < 8; i++) {
            u16 f_u = f_B[0] ^ mul_x(f_A[0], 0x990f) ^ f_A[7];
            u16 f_v = f_A[0] ^ mul_x(f_B[0], 0xc963) ^ f_B[8];
            for (int j = 0; j < 15; j++) {
                f_A[j] = f_A[j + 1];
                f_B[j] = f_B[j + 1];
            }
            f_A[15] = f_u;
            f_B[15] = f_v;
        }
    }

    void keystream(u8 *z,u8 *f_z, int t, int row, int col, int error, int flag) {
        // store the normal and faulty states at all times to check if our solution is correct
        // time 14，15，16，0  ———— 0，1，2，3。In program is 13，14，15，16————0，1，2，3。
        if(timing==14){
            for(int j=0;j<4;j++){
                for(int i=0;i<4;i++){
                    R2s[1][i][j] = (R2[j] >> (8*i)) & 0xff;
                    f_R2s[1][i][j] = (f_R2[j] >> (8*i)) & 0xff;
                }
            }
        }

        if(timing==15){
            for(int j=0;j<4;j++){
                for(int i=0;i<4;i++){
                    R1s[2][i][j] = (R1[j] >> (8*i)) & 0xff;
                    R3s[2][i][j] = (R3[j] >> (8*i)) & 0xff;
                    f_R1s[2][i][j] = (f_R1[j] >> (8*i)) & 0xff;
                    f_R3s[2][i][j] = (f_R3[j] >> (8*i)) & 0xff;
                }
            }
        }
        if(timing==0){
            for(int j=0;j<4;j++){
                for(int i=0;i<4;i++){
                    R1s[3][i][j] = (R1[j] >> (8*i)) & 0xff;
                    R2s[3][i][j] = (R2[j] >> (8*i)) & 0xff;
                    f_R1s[3][i][j] = (f_R1[j] >> (8*i)) & 0xff;
                    f_R2s[3][i][j] = (f_R2[j] >> (8*i)) & 0xff;
                }
            }
        }

        // inject fault
        if(t==timing){
            if (flag==1) f_R1[col] ^= (error<<(8*((row+4)%4))) ;
            if (flag==2) f_R2[col] ^= (error<<(8*((row+4)%4))) ;
            if (flag==3) f_R3[col] ^= (error<<(8*((row+4)%4))) ;

        }

        // keystream generation
        for (int i = 0; i < 4; i++) {
            u32 T1 = MAKEU32(B[2 * i + 9], B[2 * i + 8]);
            u32 v = (T1 ^ R1[i]) ^ R2[i];
            z[i * 4 + 0] = (v >> 0) & 0xff;
            z[i * 4 + 1] = (v >> 8) & 0xff;
            z[i * 4 + 2] = (v >> 16) & 0xff;
            z[i * 4 + 3] = (v >> 24) & 0xff;
        }

        // faulty keystream generation
        for (int i = 0; i < 4; i++) {
            u32 f_T1 = MAKEU32(f_B[2 * i + 9], f_B[2 * i + 8]);
            u32 f_v = (f_T1 ^ f_R1[i]) ^ f_R2[i];
            f_z[i * 4 + 0] = (f_v >> 0) & 0xff;
            f_z[i * 4 + 1] = (f_v >> 8) & 0xff;
            f_z[i * 4 + 2] = (f_v >> 16) & 0xff;
            f_z[i * 4 + 3] = (f_v >> 24) & 0xff;
        }

        fsm_update();
        lfsr_update();
        timing++;
    }

    void keyiv_setup(u8 *key, u8 *iv, int t, int row, int col, int error, int flag) {
        for (int i = 0; i < 8; i++) {
            A[i] = MAKEU16(iv[2 * i + 1], iv[2 * i]);
            A[i + 8] = MAKEU16(key[2 * i + 1], key[2 * i]);
            B[i] = 0x0000;
            B[i + 8] = MAKEU16(key[2 * i + 17], key[2 * i + 16]);
        }
        for (int i = 0; i < 4; i++)
            R1[i] = R2[i] = R3[i] = 0x00000000;

        // initialize faulty states
        for (int i = 0; i < 8; i++) {
            f_A[i] = MAKEU16(iv[2 * i + 1], iv[2 * i]);
            f_A[i + 8] = MAKEU16(key[2 * i + 1], key[2 * i]);
            f_B[i] = 0x0000;
            f_B[i + 8] = MAKEU16(key[2 * i + 17], key[2 * i + 16]);
        }
        for (int i = 0; i < 4; i++)
            f_R1[i] = f_R2[i] = f_R3[i] = 0x00000000;

        // initiation phase
        for (int i = 0; i < 16; i++) {
            u8 z[16],f_z[16];
            if(t==timing){
                if (flag==1) f_R1[col] ^= (error<<(8*((row+4)%4))) ;
                if (flag==2) f_R2[col] ^= (error<<(8*((row+4)%4))) ;
                if (flag==3) f_R3[col] ^= (error<<(8*((row+4)%4))) ;
            }
            keystream(z,f_z,0,0,0,0,0);
            for (int j = 0; j < 8; j++){
                A[j + 8] ^= MAKEU16(z[2 * j + 1], z[2 * j]);
                f_A[j + 8] ^= MAKEU16(f_z[2 * j + 1], f_z[2 * j]);
            }
            if (i == 14)
                for (int j = 0; j < 4; j++){
                    R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 3], key[4 * j + 2]),
                                     MAKEU16(key[4 * j + 1], key[4 * j + 0]));
                    f_R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 3], key[4 * j + 2]),
                                       MAKEU16(key[4 * j + 1], key[4 * j + 0]));
                }
            if (i == 15)
                for (int j = 0; j < 4; j++){
                    R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 19], key[4 * j + 18]),
                                     MAKEU16(key[4 * j + 17], key[4 * j + 16]));
                    f_R1[j] ^= MAKEU32(MAKEU16(key[4 * j + 19], key[4 * j + 18]),
                                       MAKEU16(key[4 * j + 17], key[4 * j + 16]));
                }
        }
    }
};

// recover state byte of R1 and R2 using input and output differences
void RB(int t, int i, int j, int flag){
    std::vector<int> newSolutions;
    newSolutions.reserve(8);
    int e,E;    // input and output differences

    if(flag==1){
        e = d_R1s[t][i][j];// input difference is at (i,j)
        E = d_R2s[t+1][(i+1+4)%4][(j-i+4)%4];// output difference is at (i+1,j-i). The column j-i is (2*E,E,E,3*E)>>>i bytes.
        for(int x=0;x<256;x++){
            if( !solutions[t][i][j].empty() &&
                std::find(solutions[t][i][j].begin(), solutions[t][i][j].end(), x) == solutions[t][i][j].end()) continue;

            int d = SBox[x] ^ SBox[ x ^ e ];
            if ( d == E ){
                newSolutions.push_back(x);
            }
        }
        solutions[t][i][j] = std::move(newSolutions);
    }
    if(flag==2){
        e = d_R2s[t][i][j];
        E = d_R3s[t+1][(i+1+4)%4][(j-i+4)%4];
//        printf("e=%x,E=%x\n",e,E);
        for(int x=0;x<256;x++){
            if( !solutions2[t][i][j].empty() &&
                std::find(solutions2[t][i][j].begin(), solutions2[t][i][j].end(), x) == solutions2[t][i][j].end()) continue;

            int d = SBox[x] ^ SBox[ x ^ e ];
            if ( d == E ){
                newSolutions.push_back(x);
            }
        }
        solutions2[t][i][j] = std::move(newSolutions); // 将 newSolutions 的内容移动到 solutions[t+1][i][j] 中，而不是复制
    }
}

int main() {
    auto start = std::chrono::high_resolution_clock::now();
    freopen("Recover Inner States.txt", "w", stdout);

    Snow5GXOR snow;
    u8 key[32];
    u8 iv[16];
    for (int i = 0; i < 32; i++) {
        key[i] = 0;
    }
    for (int i = 0; i < 16; i++) {
        iv[i] = 0;
    }

    // initialize solution sets
    initializeSolutions();
    initializeSolutions2();

    timing = 0;
    snow.keyiv_setup(key, iv,13,0,0,1,1);
    timing = 0;

    u8 z[16],f_z[16];
    for (int t = 0; t < 5; t++) {
        snow.keystream(z,f_z,99,0,0,0,0);
        for (int i = 0; i < 16; i++) {
            d_zs[t][i] = z[i] ^ f_z[i]; // compute differences of keystreams.
        }
    }
    printf("The differences of keystreams at time 0 is: \n");
    for (int t = 0; t < 1; t++) { //
        for(int i=0;i<16;i++){
            printf("%x ",d_zs[t][i]);
        }
        printf("\n");
    }
    printf("\n");

// put the differences of keystreams into C according to the Theorem 11 in the paper.
    u8 C[4][4],B[4][4]={0};
    CoreSolution sol;
    for(int j=0;j<4;j++)
        for(int i=0;i<4;i++){
            C[i][j] = d_zs[0][4*j+i];
        }

    // solve the linear system to recover the Variable
    if (solveCore(C, B, sol)) {
        print_matrix("Solution d_R2 at time 0:", B);
        printf("S2=%x,S3=%x,S4=%x; M1=%x,M2=%x,M3=%x,M4=%x\n\n",sol.S2,sol.S3,sol.S4,sol.M1,sol.M2,sol.M3,sol.M4);
    }

    // check if the solution is correct
    printf("The correct differences of R1 at time 0 is: \n");
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            printf("%x ",R1s[3][i][j]^f_R1s[3][i][j]);
        }
        printf("\n");
    }

    // check if the solution is correct
    printf("The correct differences of R2 at time 0 is: \n");
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            printf("%x ",R2s[3][i][j]^f_R2s[3][i][j]);
        }
        printf("\n");
    }

    //  solve the difference of FSM according to the Theorem 11 in the paper.
    u8 S1,S5,S55,S6,S66,S666;
    S5 = R1s[2][0][1] ^ InvSubByte(sol.M2 ^ SBox[R1s[2][0][1]] ) ;
    S55 = R1s[2][0][2] ^ InvSubByte(sol.M3 ^ SBox[R1s[2][0][2]] ) ;
    S1 = d_zs[0][4] ^ gmul(2,sol.M2) ^ S5;
    S6 = d_zs[0][0] ^ gmul(2,sol.M1) ^  gmul(2,S5) ^ gmul(2,S1);
    S66 = d_zs[0][8] ^ gmul(2,sol.M3) ^ S1 ^ S5;
    S666 = R1s[2][0][0] ^ InvSubByte(sol.M1 ^ SBox[R1s[2][0][0]] ) ^ gmul(2,S5) ;
    printf("\nS1=%x,S5=%x,S55=%x,S6=%x,S66=%x,S666=%x\n",S1,S5,S55,S6,S66,S666);
    printf("S2^M2=%x,C[1][1]=%x\n\n",sol.S2^sol.M2,C[1][1]);

    d_R2s[1][0][0] = gmul(2,S5);
    d_R2s[1][1][0] = S5;
    d_R2s[1][2][0] = S5;
    d_R2s[1][3][0] = gmul(3,S5);

    d_R3s[2][1][0]=S1;
    d_R3s[2][2][3]=sol.S4;
    d_R3s[2][3][2]=sol.S3;
    d_R3s[2][0][1]=sol.S2;

    //---------------------------------In the above, we solved the input difference and output difference.
    // In the following, we solve the candidate values of the state bytes.--------------------------------

    // solve the column 0 of R2 at time 15
    for(int i=0;i<4;i++){
        RB(1,i,0,2);
        printf("The solutions of R2[%d][0](%d) at time 15 are: ",i,R2s[1][i][0]);
        for(auto x: solutions2[1][i][0]){
            printf("%d ",x);
        }
        printf("\n");
    }

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    printf("Elapsed time: %.6fs\n", elapsed.count());

    return 0;
}

// It is recommended to enter the following code in the terminal to run the program:
//g++ -std=c++11 main.cpp Gauss.cpp -o main
//.\main.exe