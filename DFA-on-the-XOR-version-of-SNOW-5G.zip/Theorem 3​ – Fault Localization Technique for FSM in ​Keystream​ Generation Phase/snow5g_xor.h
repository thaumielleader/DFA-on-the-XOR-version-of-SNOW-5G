#ifndef SNOW5G_XOR_H
#define SNOW5G_XOR_H

#include <stdint.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

#define MAKEU32(a, b) (((u32)(a) << 16) | ((u32)(b) ))
#define MAKEU16(a, b) (((u16)(a) << 8) | ((u16)(b) ))

struct SnowV32 {
    u16 A[16], B[16]; // LFSR
    u32 R1[4], R2[4], R3[4]; // FSM
    void aes_enc_round(u32 *result, u32 *state, u32 *roundKey);
    u16 mul_x(u16 v, u16 c);
    u16 mul_x_inv(u16 v, u16 d);
    void permute_sigma(u32 *state);
    void fsm_update(void);
    void lfsr_update(void);
    void keystream(u8 *z);
    void keyiv_setup(u8 *key, u8 *iv, int is_aead_mode);
};

#endif // SNOW5G_XOR_H
