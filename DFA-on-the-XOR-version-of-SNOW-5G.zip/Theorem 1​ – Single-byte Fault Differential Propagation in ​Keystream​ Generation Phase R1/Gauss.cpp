#include "Gauss.h"
using namespace std;

u8 InvSubByte(u8 byte) {
    return InvSBox[byte];
}

void InvSubBytes(u8 state[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            state[i][j] = InvSubByte(state[i][j]);
        }
    }
}

void InvShiftRows(u8 state[4][4]) {
    u8 temp = state[1][3];
    state[1][3] = state[1][2];
    state[1][2] = state[1][1];
    state[1][1] = state[1][0];
    state[1][0] = temp;

    std::swap(state[2][0], state[2][2]);
    std::swap(state[2][1], state[2][3]);

    temp = state[3][0];
    state[3][0] = state[3][1];
    state[3][1] = state[3][2];
    state[3][2] = state[3][3];
    state[3][3] = temp;
}

void InvMixColumns(u8 state[4][4]) {
    for (int col = 0; col < 4; ++col) {
        u8 a[4] = {state[0][col], state[1][col], state[2][col], state[3][col]};

        state[0][col] = gmul(0x0E, a[0]) ^ gmul(0x0B, a[1]) ^
                        gmul(0x0D, a[2]) ^ gmul(0x09, a[3]);
        state[1][col] = gmul(0x09, a[0]) ^ gmul(0x0E, a[1]) ^
                        gmul(0x0B, a[2]) ^ gmul(0x0D, a[3]);
        state[2][col] = gmul(0x0D, a[0]) ^ gmul(0x09, a[1]) ^
                        gmul(0x0E, a[2]) ^ gmul(0x0B, a[3]);
        state[3][col] = gmul(0x0B, a[0]) ^ gmul(0x0D, a[1]) ^
                        gmul(0x09, a[2]) ^ gmul(0x0E, a[3]);
    }
}

u8 gmul(u8 a, u8 b) {
    u8 p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        bool high_bit = a & 0x80;
        a = (a << 1);
        if (high_bit) a ^= 0x1B;
        b >>= 1;
    }
    return p;
}

std::vector<u8> gaussian_elimination(std::vector<std::vector<u8>>& A,
                                     std::vector<u8>& b,
                                     int n_vars) {
    int n_eq = A.size();
    for (int col = 0; col < n_vars; col++) {
        // Find pivot row
        int pivot = -1;
        for (int row = col; row < n_eq; row++) {
            if (A[row][col] != 0) {
                pivot = row;
                break;
            }
        }
        if (pivot == -1) {
            cerr << "No unique solution exists!" << endl;
            return {};
        }
        // Swap pivot row to current row
        swap(A[col], A[pivot]);
        swap(b[col], b[pivot]);

        // Normalize pivot row
        u8 inv = 1;
        u8 coeff = A[col][col];
        // Find inverse using brute force (since 256 is small)
        for (int i = 1; i < 256; i++) {
            if (gmul(coeff, i) == 1) {
                inv = i;
                break;
            }
        }
        for (int j = col; j < n_vars; j++) {
            A[col][j] = gmul(A[col][j], inv);
        }
        b[col] = gmul(b[col], inv);

        // Eliminate other rows
        for (int row = 0; row < n_eq; row++) {
            if (row != col && A[row][col] != 0) {
                u8 factor = A[row][col];
                for (int j = col; j < n_vars; j++) {
                    A[row][j] ^= gmul(factor, A[col][j]);
                }
                b[row] ^= gmul(factor, b[col]);
            }
        }
    }

    vector<u8> solution(n_vars);
    for (int i = 0; i < n_vars; i++) {
        solution[i] = b[i];
    }
    return solution;
}

bool solveAB(const u8 C[4][4], u8 A[4][4], u8 B[4][4]) {
    // generate coefficient matrix and constants
    vector<vector<u8>> coeff;
    vector<u8> constants;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            vector<u8> row(8, 0);
            // coefficients of A
            switch (i) {
                case 0: row[0] = (j == 0) ? 0x02 : (j < 3) ? 0x01 : 0x03; break;
                case 1: row[1] = (j == 3) ? 0x02 : (j == 2) ? 0x03 : 0x01; break;
                case 2: row[2] = (j == 1) ? 0x03 : (j == 2) ? 0x02 : 0x01; break;
                case 3: row[3] = (j == 0) ? 0x03 : (j == 1) ? 0x02 : 0x01; break;
            }
            // coefficients of B
            u8 b_coeff = (i == 0) ? 0x02 : (i == 3) ? 0x03 : 0x01;
            row[4 + j] = b_coeff;

            coeff.push_back(row);
            constants.push_back(C[i][j]);
        }
    }

    // solve
    vector<u8> solution = gaussian_elimination(coeff, constants, 8);
    if (solution.empty()) return false;

    u8 S1 = solution[0], S2 = solution[1], S3 = solution[2], S4 = solution[3];
    u8 M1 = solution[4], M2 = solution[5], M3 = solution[6], M4 = solution[7];

    // construct A
    for (int j = 0; j < 4; j++) {
        A[0][j] = gmul(j == 0 ? 0x02 : (j < 3 ? 0x01 : 0x03), S1);
        A[1][j] = gmul(j == 3 ? 0x02 : (j == 2 ? 0x03 : 0x01), S2);
        A[2][j] = gmul(j == 1 ? 0x03 : (j == 2 ? 0x02 : 0x01), S3);
        A[3][j] = gmul(j == 0 ? 0x03 : (j == 1 ? 0x02 : 0x01), S4);
    }

    // construct B
    const u8 coeffs[4] = {0x02, 0x01, 0x01, 0x03};
    u8 M[4] = {M1, M2, M3, M4};
    for (int col = 0; col < 4; col++) {
        for (int row = 0; row < 4; row++) {
            B[row][col] = gmul(coeffs[row], M[col]);
        }
    }

    return true;
}

void print_matrix(const char* name, const u8 m[4][4]) {
    cout << name << ":\n";
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << hex << setw(2) << setfill('0')
                 << static_cast<int>(m[i][j]) << " ";
        }
        cout << endl;
    }
    cout << endl;
}